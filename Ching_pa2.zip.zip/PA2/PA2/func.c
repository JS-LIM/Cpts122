/*******************************************************************************************
* Programmer: Dillon Ching                                                                 *
* Collaborated With: Derrick Le                                                            *
* Class: CptS 122, Fall 2016; Lab Section 5                                                *
* Programming Assignment: PA2                                                              *
* Date: 9/14/16                                                                            *
* Description: This program isn't finished, will be for PA3                                *
*******************************************************************************************/

#include "Header.h"

int display_menu()
{
	int menu_choice;

	do
	{
		printf("Hello, welcome to your Digital Music Manager\nEnter in the number of your choice\n1. Load\n2. Store\n3. Display\n4. Insert\n5. Delete\n6. Edit\n7. Sort\n8. Rate\n9. Exit\n");
		scanf("%d", &menu_choice);
	} while (menu_choice == NULL);

	return menu_choice;
}

Node *makeNode(Record newData, FILE *infile)
{
	char line[200] = "", *token = NULL, *temp = NULL;
	Node *pMem = NULL;

	pMem = (Node *)malloc (sizeof(Node));

	if (pMem != NULL)
	{
		pMem->pNext = NULL;
		pMem->pPrev = NULL;
		pMem->data = newData;
	}
	

	if (infile != NULL)
	{
		printf("File opened successfully\n");
		fgets(line, 200, infile);

		if (line[0] == '\"')
		{
			token = strtok(line, ",");
			strcpy(pMem->data.artist, token);

			temp = token;

			temp = strtok(NULL, ",");
			strcat(pMem->data.artist, temp);
			
			token = strtok(NULL, ",");
			strcpy(pMem->data.album_title, token);

			token = strtok(NULL, ",");
			strcpy(pMem->data.song_title, token);

			token = strtok(NULL, ",");
			strcpy(pMem->data.genre, token);

			token = strtok(NULL, ":");
			pMem->data.time.minutes = atoi(token);

			token = strtok(NULL, ",");
			pMem->data.time.seconds = atoi(token);

			token = strtok(NULL, ",");
			pMem->data.times_played = atoi(token);

			token = strtok(NULL, ",");
			pMem->data.rating = atoi(token);
		}

		else
		{
			token = strtok(line, ",");
			strcpy(pMem->data.artist, token);

			token = strtok(NULL, ",");
			strcpy(pMem->data.album_title, token);

			token = strtok(NULL, ",");
			strcpy(pMem->data.song_title, token);

			token = strtok(NULL, ",");
			strcpy(pMem->data.genre, token);

			token = strtok(NULL, ":");
			pMem->data.time.minutes = atoi(token);

			token = strtok(NULL, ",");
			pMem->data.time.seconds = atoi(token);

			token = strtok(NULL, ",");
			pMem->data.times_played = atoi(token);

			token = strtok(NULL, ",");
			pMem->data.rating = atoi(token);
		}
	}

	return pMem;
}

int insertFront(Node **pList, Record newData, FILE *infile)
{
	Node *pMem = NULL, *pCur = NULL;
	int success = 0;

	pMem = makeNode(newData, infile);

	if (pMem != NULL)
	{
		success = 1;

		if (*pList == NULL)
			*pList = pMem;

		else
		{
			pCur = pList;
			pMem->pNext = *pList;
			*pList = pMem;
		}
	}

	return success;
}

void printList(Node *pHead)
{
	while (pHead != NULL)
	{
		printf("artist: %s\n", pHead->data.artist);
		printf("album_title: %s\n", pHead->data.album_title);
		printf("song_title: %s\n", pHead->data.song_title);
		printf("genre: %s\n", pHead->data.genre);
		printf("minutes: %d\n", pHead->data.time.minutes);
		printf("seconds: %d\n", pHead->data.time.seconds);
		printf("times_played: %d\n", pHead->data.times_played);
		printf("rating: %d\n", pHead->data.rating);
		printf("pNext %d\n", pHead->pNext);
		pHead = pHead->pNext;
	}
}

int count_file_lines(FILE *infile)
{
	int count = 0;
	char line[200] = "", line_prev[200] = "";

	line[200] = fgets(line, 200, infile);

	while (strcmp(line[200], line_prev[200]) != 0)
	{
		line_prev[200] = line[200];
		line[200] = fgets(line, 200, infile);
		count++;
		printf("%s\n", line);
		//printf("%d\n", count);
	}

	/*line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);

	line[200] = fgets(line, 200, infile);
	printf("%s\n", line);*/

	return count;
}