/*******************************************************************************************
* Programmer: Dillon Ching                                                                 *
* Collaborated With: Derrick Le                                                            *
* Class: CptS 122, Fall 2016; Lab Section 5                                                *
* Programming Assignment: PA2                                                              *
* Date: 9/14/16                                                                            *
* Description: This program isn't finished, will be for PA3                                *
*******************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct duration
{
	int minutes;
	int seconds;
} Duration;

typedef struct record
{
	char artist[30];
	char album_title[30];
	char song_title[30];
	char genre[30];
	struct duration time;
	int times_played;
	int rating;
} Record;

typedef struct node
{
	Record data;
	struct node *pNext, *pPrev;
} Node;

int display_menu();
Node *makeNode(Record newData, FILE *infile);
int insertFront(Node **pList, Record newData, FILE *infile);
void printList(Node *pHead);
int count_file_lines(FILE *infile);
