#pragma once

#include "Node.h"

class ListQueue
{
public:
	ListQueue();
	~ListQueue();

	Node * getHeadPtr();
	void setHeadPtr(Node * pNewHead);

	Node * getTailPtr();
	void setTailPtr(Node * pNewTail);

	bool enqueue(sf::Texture newBallTexture, sf::Texture newBallTexture1, sf::Texture newQueueTexture);
	bool dequeue();


private:
	Node *mpHead;
	Node *mpTail;

	Node * makeNode(sf::Texture newBallTexture, sf::Texture newBallTexture1, sf::Texture newQueueTexture);
};

ListQueue::ListQueue()
{
	this->mpHead = nullptr;
	this->mpTail = nullptr;
}

Node * ListQueue::getHeadPtr()
{
	return this->mpHead;
}

void ListQueue::setHeadPtr(Node * pNewNode)
{
	this->mpHead = pNewNode;
}

Node * ListQueue::getTailPtr()
{
	return this->mpTail;
}

void ListQueue::setTailPtr(Node * pNewTail)
{
	this->mpTail = pNewTail;
}

bool ListQueue::enqueue(sf::Texture newBallTexture, sf::Texture newBallTexture1, sf::Texture newQueueTexture)
{
	Node *pMem = makeNode(newBallTexture, newBallTexture1, newQueueTexture);

	bool success = false;

	if (pMem != nullptr)//node is not empty
	{
		success = true;
		if (mpTail != nullptr)//queue is not empty
		{
			mpTail->setNextPtr(pMem);
			mpTail = pMem;
		}
		else
		{
			mpHead = mpTail = pMem;
		}
	}

	return success;
}

bool ListQueue::dequeue()
{
	Node *pTemp = mpHead;

	if (mpHead == mpTail)
	{
		mpHead = mpTail = nullptr;
	}
	else
	{
		mpHead = mpHead->getNextPtr();
	}

	free(pTemp);
}

//private function
Node * ListQueue::makeNode(sf::Texture newBallTexture, sf::Texture newBallTexture1, sf::Texture newQueueTexture)
{
	Node *pMem = new Node(newBallTexture, newBallTexture1, newQueueTexture);

	return pMem;
}