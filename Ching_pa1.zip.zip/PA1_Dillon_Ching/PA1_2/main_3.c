/*******************************************************************************************
* Programmer: Dillon Ching                                                                 *
* Collaborated With: Derrick Le                                                            *
* Class: CptS 122, Fall 2016; Lab Section 5                                                *
* Programming Assignment: PA1 Task1                                                        *
* Date: 9/4/16                                                                             *
* Description: This program decrypts and encrypts messages with the Caesar Shift Cipher.   *
*******************************************************************************************/

#include "Header_3.h"
#include "Driver_3.h"

int main()
{
	testPA1_3();

	return 0;
}