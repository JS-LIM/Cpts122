/*******************************************************************************************
* Programmer: Dillon Ching                                                                 *
* Collaborated With: Derrick Le                                                            *
* Class: CptS 122, Fall 2016; Lab Section 5                                                *
* Programming Assignment: PA1 Task1                                                        *
* Date: 9/4/16                                                                             *
* Description: This program bubble sorts a list of names                                   *
*******************************************************************************************/

#include "Header_1.h"
#include "Driver_1.h"

int main(void)
{
	testBubbleSortAscend();

	return 0;
}