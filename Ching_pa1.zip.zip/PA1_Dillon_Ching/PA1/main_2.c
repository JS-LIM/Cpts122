/*******************************************************************************************
* Programmer: Dillon Ching                                                                 *
* Collaborated With: Derrick Le                                                            *
* Class: CptS 122, Fall 2016; Lab Section 5                                                *
* Programming Assignment: PA1 Task1                                                        *
* Date: 9/4/16                                                                             *
* Description: This program recursively finds a path through a maze.                       *
*******************************************************************************************/

#include "Header_2.h"
#include "Driver_2.h"

int main()
{
	testPA1_2();
}